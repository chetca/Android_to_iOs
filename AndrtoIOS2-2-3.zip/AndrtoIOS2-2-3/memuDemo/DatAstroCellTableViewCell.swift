//
//  DatAstroCellTableViewCell.swift
//  memuDemo
//
//  Created by Dugar Badagarov on 04/10/2017.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit

class DatAstroCellTableViewCell: UITableViewCell {

    @IBOutlet var TextLbl: UILabel!
    @IBOutlet var TitleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
