//
//  DatsansTableViewController.swift
//  memuDemo
//
//  Created by Dugar Badagarov on 30/08/2017.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit

class DatsansTableViewController: UITableViewController {

    @IBOutlet var btnMenuButton: UIBarButtonItem!
    var paramDict:[String:[String]] = Dictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if revealViewController() != nil {                        
            
            btnMenuButton.target = revealViewController()                        
            btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
          
                paramDict = JSONTaker.shared.loadData(API: "dat", paramNames: ["title", "text"])
            
            //loadAstrologicalData(baseURL: "file:///Users/dugar/Downloads/feed.json")            
            //print (paramDict)            
            
            tableView.contentInset = UIEdgeInsetsMake(20.0, 0.0, 0.0, 0.0)        
            tableView.rowHeight = UITableViewAutomaticDimension
            tableView.estimatedRowHeight = 44   
        }
        
       // tableView.allowsSelection = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (paramDict["title"]?.count)!
    }
    @objc(tableView:didSelectRowAtIndexPath:) override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        //print("You selected name : "+(self.paramDict["date"]?[indexPath.row])!)
        
        var cell = tableView.cellForRow(at: indexPath) as! DatAstroCellTableViewCell
        
        StringLblText   = (self.paramDict["title"]?[indexPath.row])!
        StringText  = (self.paramDict["text"]?[indexPath.row])!
        
        performSegue(withIdentifier: "segue", sender: self)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "DatAstroCellTableViewCell") as! DatAstroCellTableViewCell     
        
        cell.TitleLbl.text = (paramDict["title"]?[indexPath.row])!
        cell.TextLbl.setHTML(html: (paramDict["text"]?[indexPath.row])!)
        cell.sizeToFit()
        
        cell.TitleLbl.font = UIFont.boldSystemFont(ofSize: 16)
        
        return cell
    }
}
