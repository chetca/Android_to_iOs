//
//  FuckingYandex.swift
//  memuDemo
//
//  Created by Dugar Badagarov on 02/10/2017.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit

class FuckingYandex: UIViewController {

    @IBOutlet var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()                
        
        webView.loadRequest(URLRequest(url: URL(string: "https://money.yandex.ru/quickpay/shop-widget?writer=buyer&targets=&targets-hint=&default-sum=&button-text=11&hint=&successURL=&quickpay=shop&account=410012817959854")!))                
        
        
        DispatchQueue.main.async(execute: {
            while (self.webView.isLoading) {}            
            print (self.webView.frame.width)
            print (self.webView.bounds.width)
            print (self.webView.contentScaleFactor)
            
            return
        })
        
        print (UIApplication.shared.keyWindow?.frame)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
//89082087328
    }

}
