//
//  CurrentNewsViewController.swift
//  memuDemo
//
//  Created by Dugar Badagarov on 23/08/2017.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit

class CurrentNewsViewController: UIViewController {
    
    @IBOutlet var lblText: UILabel!
    @IBOutlet var dataField: UILabel!    
    @IBOutlet var textNews: UILabel!
    @IBOutlet var img: UIImageView!
    @IBOutlet var spinner: UIActivityIndicatorView!       
    @IBOutlet var imgHeight: NSLayoutConstraint!
    
    var images = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblText.text = StringLblText
        dataField.text = StringDataField
        textNews.text = StringText
        if (localError != ""){
            JSONTaker.shared.showAlert(title: localError, message: "", viewController: self)}
            
        else{
            //JSONTaker.shared.loadImg(imgURL: StringUrlImg, img: [img], spinner: spinner)
            if (GlobalImg != nil) {img.image = GlobalImg}
            else {
                JSONTaker.shared.loadImg(imgURL: StringUrlImg, img: [img], spinner: spinner)
            }
        }
        img.sizeToFit()
        
        textNews.setHTML(html: textNews.text!)                                                
    }    
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.main.async(execute: {
            var cnt = 0;
            while (true) {
                if (self.img.bounds.height != 0.0 && self.img.bounds.width != 0.0) {cnt=cnt+1;}
                if (self.img.bounds.height != 0.0 && self.img.bounds.width != 0.0 && cnt==5000) {
                    self.imgHeight.constant = self.img.bounds.width * ((self.img.image?.size.height)!/(self.img.image?.size.width)!)
                    
                    self.img.frame = CGRect(x: self.img.frame.origin.x,
                                            y: self.img.frame.origin.y,
                                            width: self.img.frame.width,
                                            height: self.imgHeight.constant)                    
                    return;
                }                
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
