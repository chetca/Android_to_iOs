//
//  CurrentAlbumCollectionCell.swift
//  memuDemo
//
//  Created by Dugar Badagarov on 02/09/2017.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit

class CurrentAlbumCollectionCell: UICollectionViewCell {
    @IBOutlet var img: UIImageView!
    @IBOutlet var spinner: UIActivityIndicatorView!
}
